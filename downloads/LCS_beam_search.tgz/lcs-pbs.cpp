/***************************************************************************
                       lcs-pbs.cpp  -  description
                             -------------------
    begin                : Fri Jan 11 2008
    copyright            : (C) 2008 by Christian Blum
    email                : christian.c.blum@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "Timer.h"
#include "PBS.h"
#include "LCS_instance.h"
#include "Solution.h"
#include <string>
#include <list>
#include <vector>
#include <cmath>
#include <cstring>
#include <iomanip>

// the following five variables are involved in termination criteria issues
bool input_file_given = false;

// size of the beam
int beam_size = 10;

// construction
bool apply_filter = true;
double mu = 2.0;
int greedy_info = 0;

// the problem instance
LCS_instance* instance = NULL;

// t: a variable that is involved in initializing the random generator
time_t t;

// variable that holds the name of the input file
vector<string> files;

void usage(void) {
    printf("\n"
           "Usage: %s [OPTIONS] [FILE...]\n\n", "lcs-pbs");

    printf(
"Probabilistic Beam Search for the Longest Common Subsequence Problem.\n\n"

"Options:\n"
" -h, --help          print this summary and exit.                          \n"
" -beamwidth                                                                \n"
" -mu                                                                       \n"
" -filter {yes|no}                                       		    \n"
" -greedy {0|1}                                                             \n"
"\n");
}

/* The method read_parameters is used to read-in the command line parameters */

void read_parameters(int argc, char **argv) {

    int iarg=1;

    while (iarg < argc) {
        if (strcmp (argv[iarg], "-h") == 0 || strcmp (argv[iarg], "--help") == 0) {
            usage ();
            exit (0);
        }
        else if (strcmp(argv[iarg],"-beamwidth")==0) beam_size = atoi(argv[++iarg]);
        else if (strcmp(argv[iarg],"-greedy")==0) greedy_info = atoi(argv[++iarg]);
        else if (strcmp(argv[iarg],"-mu")==0) mu = atof(argv[++iarg]);
        else if (strcmp(argv[iarg],"-filter")==0) {
            if (strcmp(argv[++iarg],"no")==0) apply_filter = false;
            else apply_filter = true;
        }
        else {
            files.push_back(argv[iarg]);
            input_file_given = true;
        }
        iarg++;
    }
    if (input_file_given == false) {
        printf("No input file given.");
        printf("\n");
        exit(1);
    }
}


/* 'main' is the main body of the program */

int main( int argc, char **argv ) {

    // first the command line parameters have to be read
    if ( argc < 2 ) exit(1);
    else read_parameters(argc,argv);

    std::cout << std::setprecision(1) << std::fixed;

    vector<double> results(files.size());
    vector<double> times(files.size());

    /* the following loop iterates over the input files */
    for (int fi = 0; fi < files.size(); fi++) {
    
        // reading the problem instance
        instance = new LCS_instance(files[fi]);

        /* initialization of the PBS object */
        PBS* myPBS = new PBS(instance);

        // upon declaration of a variable of type 'Timer' the time is running ... 
        Timer timer;
    
        vector<Solution*> bests = myPBS->beam_construct(beam_size,mu,apply_filter,greedy_info);
        double computation_time = timer.elapsed_time(Timer::VIRTUAL);   
        results[fi] = double(bests[0]->value());
        times[fi] = computation_time;

        if (not bests[0]->is_valid()) {
            cout << "SOMETHING WRONG: NOT A VALID SOLUTION" << endl;
            exit (1);
        }
        else cout << files[fi] << "\t" << bests[0]->value() << "\t" << computation_time << endl;

        for (int i = 0; i < int(bests.size()); ++i) delete(bests[i]);
        bests.clear();

        delete(instance);
        delete(myPBS);
    }
    double r_mean = 0.0;
    double t_mean = 0.0;
    for (int i = 0; i < results.size(); i++) {
        r_mean = r_mean + results[i];
        t_mean = t_mean + times[i];
    }
    r_mean = r_mean / ((double)results.size());
    t_mean = t_mean / ((double)times.size());
    double rsd = 0.0;
    double tsd = 0.0;
    for (int i = 0; i < results.size(); i++) {
      rsd = rsd + pow(results[i]-r_mean,2.0);
      tsd = tsd + pow(times[i]-t_mean,2.0);
    }
    rsd = rsd / ((double)(results.size()-1.0));
    if (rsd > 0.0) {
        rsd = sqrt(rsd);
    }
    tsd = tsd / ((double)(times.size()-1.0));
    if (tsd > 0.0) {
        tsd = sqrt(tsd);
    }
    cout << r_mean << "\t" << rsd << "\t" << t_mean << "\t" << tsd << endl;
}

