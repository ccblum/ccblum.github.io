 /***************************************************************************
                        Solution.cpp  -  description
                             -------------------
    begin                : Mon Jan 29 2007
    copyright            : (C) 2007 by Christian Blum
    email                : christian.c.blum@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "Solution.h"

Solution::Solution() {

    instance = NULL;
}

Solution::Solution(LCS_instance* my_instance) {

    instance = my_instance;
    for (int i = 0; i < instance->n_of_sequences; i++) {
        pointer.push_back(-1);
        int lm = (instance->sequences)[i].size();
        for (int j = 0; j < instance->alphabet_size; j++) {
            int pos = search_position(i,j);
            next_char[i].push_back(pos);
            if (pos < lm) lm = pos;
        }
        left_most.push_back(lm);
    }
    remaining = instance->occurances;
    min_remaining = instance->min_occurances;
    ub_value = -1;
    finished = false;
    greedy_weight_sum = 0.0;
}

Solution::~Solution() {
}

Solution* Solution::copy() {

    Solution* newSol = new Solution();
    newSol->instance = instance;
    newSol->sequence = sequence;
    newSol->pointer = pointer;
    newSol->next_char = next_char;
    newSol->min_remaining = min_remaining;
    newSol->remaining = remaining;
    newSol->ub_value = ub_value;
    newSol->finished = finished;
    newSol->left_most = left_most;
    newSol->greedy_weight_sum = greedy_weight_sum;
    return newSol;
}

Solution* Solution::construction_copy() {

    Solution* newSol = new Solution();
    newSol->pointer = pointer;
    newSol->instance = instance;
    newSol->next_char = next_char;
    newSol->finished = finished;
    return newSol;
}

int Solution::value() const {
    return sequence.size();
}

int Solution::upper_bound() {

    if (ub_value == -1) {
        ub_value = sequence.size();
        for (int j = 0; j < instance->alphabet_size; j++) ub_value = min_remaining[j] + ub_value;
    }
    return ub_value;
}

void Solution::add(int letter) {

    ub_value = -1;
    sequence.push_back(letter);
    for (int i = 0; i < instance->n_of_sequences; i++) {
        for (int k = pointer[i]+1; k <= next_char[i][letter]; k++) {
            remaining[i][(instance->sequences)[i][k]] = remaining[i][(instance->sequences)[i][k]] - 1;
        }
        pointer[i] = next_char[i][letter];
        int lm = (instance->sequences)[i].size();
        for (int j = 0; j < instance->alphabet_size; j++) {
            if (remaining[i][j] < min_remaining[j]) min_remaining[j] = remaining[i][j];
            if (next_char[i][j] <= pointer[i]) next_char[i][j] = search_position(i,j);
            if (min_remaining[j] > 0) {
                if (next_char[i][j] < lm) {
                    lm = next_char[i][j];
                }
            }
        }
        left_most[i] = lm;
    }
}

void Solution::construction_add(int letter) {

    for (int i = 0; i < instance->n_of_sequences; i++) {
        pointer[i] = next_char[i][letter];
        for (int j = 0; j < instance->alphabet_size; j++) {
            if (next_char[i][j] <= pointer[i]) next_char[i][j] = search_position(i,j);
        }
    }
}

void Solution::print_one_line() const {
    print_one_line (stdout);
}

void Solution::print_one_line (FILE *stream) const {

    fprintf (stream, "%d\t", int(this->value()));

    for (int i = 0; i < int(sequence.size()); i++) {
        fprintf (stream, "%c", (instance->int2char)[sequence[i]]);
    }

    fprintf (stream, "\n");
}

void Solution::writeToScreen() {

    for (int i = 0; i < sequence.size(); i++) cout << (instance->int2char)[sequence[i]];
    cout << endl;
}

bool Solution::is_complete() {

    return finished;
}

int Solution::search_position(int seq, int let) {

    int ret = (instance->sequences)[seq].size();
    bool found = false;
    for (int i = pointer[seq]+1; ((i < (instance->sequences)[seq].size()) && !found); i++) {
        if ((instance->sequences)[seq][i] == let) {
            ret = i;
            found = true;
        }
    }
    return ret;
}

int Solution::search_position(int seq, int pointer, int let) {

    int ret = (instance->sequences)[seq].size();
    bool found = false;
    for (int i = pointer+1; ((i < (instance->sequences)[seq].size()) && !found); i++) {
        if ((instance->sequences)[seq][i] == let) {
            ret = i;
            found = true;
        }
    }
    return ret;
}

int Solution::search_position(int seq, int pointer, int let, int& gap_size) {

    int ret = (instance->sequences)[seq].size();
    bool found = false;
    gap_size = 0;
    for (int i = pointer+1; ((i < (instance->sequences)[seq].size()) && !found); i++) {
        if ((instance->sequences)[seq][i] == let) {
            ret = i;
            found = true;
        }
        else gap_size++;
    }
    return ret;
}

bool Solution::is_valid() {

    bool solution_correct = true;
    for (int i = 0; ((i < instance->n_of_sequences) && solution_correct); i++) {
        int pointer = -1;
        bool correct = true;
        for (int j = 0; j < sequence.size(); j++) {
            pointer = search_position(i,pointer,sequence[j]);
            if (pointer == (instance->sequences)[i].size()) correct = false;
        }
        if (!correct) solution_correct = false;
    }
    return solution_correct;
}

int Solution::domination_relation(int l1, int l2) {

    bool dominates = false;
    bool dominated = false;
    bool stop = false;
    for (int i = 0; ((i < instance->n_of_sequences) && !stop); i++) {
        if (next_char[i][l1] < next_char[i][l2]) dominates = true;
        else {
            if (next_char[i][l1] > next_char[i][l2]) dominated = true;
        }
        if (dominates && dominated) stop = true;
    }
    if (stop) return 0;
    else {
        if (dominates) return 1;
        else return -1;
    }
}

