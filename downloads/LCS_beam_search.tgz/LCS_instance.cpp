 /***************************************************************************
                     LCS_instance.cpp  -  description
                             -------------------
    begin                : Thu Sep 21 2006
    copyright            : (C) 2006 by Christian Blum
    email                : cblum@lsi.upc.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include "LCS_instance.h"


LCS_instance::LCS_instance() {

}

LCS_instance::LCS_instance(string lcsFile) {

    ifstream indata;
    indata.open(lcsFile.c_str());
    if (not indata) cout << "Error: file could not be opened" << endl;

    indata >> n_of_sequences >> alphabet_size;

    map<char,int> char2int;
    int count = 0;
    char aChar;
 
    for (int i = 0; i < n_of_sequences; i++) {
        int length;
        indata >> length;
        vector<int> test(length,0);
        sequences[i] = test;
        string aString;
        indata >> aString;
        for (int j = 0; j < length; j++) {
            int theInt;
            if (char2int.count(aString[j]) == 0) {
                char2int[aString[j]] = count;
                int2char[count] = aString[j];
                theInt = count;
                count++;
            }
            else theInt = char2int[aString[j]];
            sequences[i][j] = theInt;
        }
    }

    for (int i = 0; i < n_of_sequences; i++) {
        vector<int> test(100,0);
        occurances[i] = test;
        for (int k = 0; k < sequences[i].size(); k++) {
            occurances[i][sequences[i][k]] = occurances[i][sequences[i][k]]+1;
        }
        if (i == 0) {
            for (int j = 0; j < alphabet_size; j++) {
                min_occurances.push_back(occurances[i][j]);
            }
        }
        else {
            for (int j = 0; j < alphabet_size; j++) {
                if (occurances[i][j] < min_occurances[j]) {
                    min_occurances[j] = occurances[i][j];
                }
            }      
        }
    }
    indata.close();
}

LCS_instance::~LCS_instance() {

}

void LCS_instance::writeToScreen() {

  cout << endl;
  cout << "# of sequences: " << n_of_sequences << endl;
  cout << "Alphabet size : " << alphabet_size << endl;
  cout << "Sequences: " << endl;
  for (int i = 0; i < n_of_sequences; i++) {
    cout << sequences[i].size() << " ";
    for (int j = 0; j < sequences[i].size(); j++) {
      cout << int2char[sequences[i][j]];
    }
    cout << endl;
  }
}

void LCS_instance::makeReverse() {

  for (int i = 0; i < n_of_sequences; i++) {
    vector<int> newVec;
    for (vector<int>::reverse_iterator it = sequences[i].rbegin(); it != sequences[i].rend(); it++) {
      newVec.push_back(*it);
    }
    sequences[i] = newVec;
  }
}
