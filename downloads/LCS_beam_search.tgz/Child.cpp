 /***************************************************************************
                          Child.cpp  -  description
                             -------------------
    begin                : Fri Feb 02 2007
    copyright            : (C) 2007 by Christian Blum
    email                : cblum@lsi.upc.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "Child.h"

Child::Child() {

  my_sol = NULL;
}

Child::Child(Solution* aSol, int aLetter, double gweight) {

  my_sol = aSol;
  letter = aLetter;
  greedy_weight = gweight;
}

Child::~Child() {
}

