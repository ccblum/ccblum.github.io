using namespace std;
#ifndef DEBUG
#define DEBUG 0
#endif

#if DEBUG >= 1
#define DEBUG1(X) X;(void)0
#else  
#define DEBUG1(X) (void)0
#endif

#if DEBUG >= 2
#define DEBUG2(X) X;(void)0
#else  
#define DEBUG2(X) (void)0
#endif

#if DEBUG >= 3
#define DEBUG3(X) X;(void)0
#else  
#define DEBUG3(X) (void)0
#endif

#if DEBUG >= 4
#define DEBUG4(X) X;(void)0
#else  
#define DEBUG4(X) (void)0
#endif
