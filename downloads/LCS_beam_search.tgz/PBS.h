/***************************************************************************
                            PBS.h  -  description
                             -------------------
    begin                : Fri Jan 11 2008
    copyright            : (C) 2008 by Christian Blum
    email                : christian.c.blum@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef PBS_H
#define PBS_H

#include "config.h"

#include <string>
#include <vector>
#include <map>
#include "Solution.h"
#include "LCS_instance.h"
#include "Child.h"

class PBS {

public:

	PBS();
	PBS(LCS_instance* anInstance);
	~PBS();
	
public:

        LCS_instance* instance;

        double get_rel_value(Solution* aSol, int letter);
        int get_nb_value(Solution* aSol, int letter);
        vector<Solution*> beam_construct(int beam_size, double mu, bool filter, int greedy_info);
        void get_options(Solution* sol, vector<int>& options);
        void produce_rel_children(Solution* aSol, list<Child*>& children, vector<int>& options, double& basesum);
        void produce_nb_children(Solution* aSol, list<Child*>& children, vector<int>& options, double& basesum);
        void filter_children(list<Child*>& children, double& basesum);
        int child_domination_relation(Child* c1, Child* c2);

        friend bool child_compare(const Child* c1, const Child* c2);
        friend bool solution_compare(const Solution* s1, const Solution* s2);

};

#endif
