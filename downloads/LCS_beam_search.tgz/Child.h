/***************************************************************************
                           Child.h  -  description
                             -------------------
    begin                : Fri Feb 02 2007
    copyright            : (C) 2007 by Christian Blum
    email                : cblum@lsi.upc.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef CHILD_H
#define CHILD_H

#include "config.h"

#include "Solution.h"

class Child {

public:

  Solution* my_sol;
  int letter;
  double greedy_weight;
  double value;
  double non_dominated;

  Child();
  Child(Solution* aSol, int aLetter, double gweight);
  ~Child();

};

#endif
