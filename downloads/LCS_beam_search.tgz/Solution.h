/***************************************************************************
                         Solution.h  -  description
                             -------------------
    begin                : Mon Jan 29 2007
    copyright            : (C) 2007 by Christian Blum
    email                : christian.c.blum@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef SOLUTION_H
#define SOLUTION_H

#include "config.h"

#include <list>
#include <vector>
#include <map>
#include "LCS_instance.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

class Solution {

public:

    vector<int> sequence;
    map<int,vector<int> > remaining;
    vector<int> pointer;
    map<int,vector<int> > next_char;
    vector<int> min_remaining;
    vector<int> left_most;
    LCS_instance* instance;
    int ub_value;
    bool finished;
    double greedy_weight_sum;

    Solution();
    Solution(LCS_instance* my_instance);
    ~Solution();

    int value() const;
    int upper_bound();
    Solution* copy();
    Solution* construction_copy();
    void add(int letter);
    void construction_add(int letter);
    void print_one_line (void) const;
    void print_one_line (FILE *stream) const;
    void writeToScreen();
    bool is_complete();
    int search_position(int seq, int let);
    int search_position(int seq, int pointer, int let);
    int search_position(int seq, int pointer, int let, int& gap_size);
    bool is_valid();
    int domination_relation(int l1, int l2);

};

#endif
