/***************************************************************************
                     LCS_instance.h  -  description
                             -------------------
    begin                : Mon Jan 29 2007
    copyright            : (C) 2007 by Christian Blum
    email                : cblum@lsi.upc.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef LCS_INSTANCE_H
#define LCS_INSTANCE_H

#include "config.h"

#include <string>
#include <vector>
#include <map>


class LCS_instance {

public:

	LCS_instance();
	LCS_instance(string lcsFile);
	~LCS_instance();
	
public:
 
        map<int,vector<int> > sequences;
	int alphabet_size;
        int n_of_sequences;
        int optimal;
        
        map<int,vector<int> > occurances;
        vector<int> min_occurances;
        map<int,char> int2char;

        void writeToScreen();
        void makeReverse();

};

#endif
