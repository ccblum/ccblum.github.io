/***************************************************************************
                        PBS.cpp  -  description
                             -------------------
    begin                : Fri Jan 11 2008
    copyright            : (C) 2008 by Christian Blum
    email                : christian.c.blum@gmail.com
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <math.h>
#include "PBS.h"


bool child_compare(const Child* c1, const Child* c2) {

    return c1->greedy_weight > c2->greedy_weight;
}

bool solution_compare(const Solution* s1, const Solution* s2) {

    return s1->ub_value > s2->ub_value;
}

PBS::PBS() {

    instance = NULL;
}

PBS::PBS(LCS_instance* anInstance) {

    instance = anInstance;
}

PBS::~PBS() {
}

double PBS::get_rel_value(Solution* aSol, int letter) {

    double dist = 1000000.0;
    if ((aSol->min_remaining)[letter] > 0) {
        dist = 0.0;
        for (int i = 0; i < instance->n_of_sequences; i++) {
            dist = dist + (((double)((aSol->next_char)[i][letter] - (aSol->pointer)[i]))  / ((double)((instance->sequences)[i].size() - (aSol->pointer)[i])));
        }
    }
    return (1.0 / dist);
}

int PBS::get_nb_value(Solution* aSol, int letter) {

    int min_dist = 1000000;
    for (int i = 0; i < instance->n_of_sequences; i++) {
        int dist = (instance->sequences)[i].size() - (aSol->next_char)[i][letter];
        if (dist < min_dist) min_dist = dist;
    }
    return min_dist;
}

void PBS::produce_rel_children(Solution* aSol, list<Child*>& children, vector<int>& options, double& basesum) {

    list<Child*> childList;
    for (int l = 0; l < options.size(); l++) {
        int j = options[l];
        double val = get_rel_value(aSol,j);
        Child *newChild = new Child(aSol,j,val);
        childList.push_back(newChild);
    }
    childList.sort(child_compare);
    double heuristic_upper = (double)((aSol->sequence).size() + 1);
    int count = 1;
    for (list<Child*>::iterator anIt = childList.begin(); anIt != childList.end(); anIt++) {
        Child* aChild = *anIt;
        aChild->greedy_weight = (double)count;
        count++;
        double val = heuristic_upper / (aChild->greedy_weight + aSol->greedy_weight_sum);
        basesum = basesum + val;
        aChild->value = val;
        children.push_back(aChild);
    }
}

void PBS::produce_nb_children(Solution* aSol, list<Child*>& children, vector<int>& options, double& basesum) {

    list<Child*> childList;
    for (int l = 0; l < options.size(); l++) {
        int j = options[l];
        int val = get_nb_value(aSol,j) + 1;
        Child* newChild = new Child(aSol,j,((double)val));
        childList.push_back(newChild);
    }
    childList.sort(child_compare);
    double heuristic_upper = (double)((aSol->sequence).size() + 1);
    int count = 1;
    for (list<Child*>::iterator anIt = childList.begin(); anIt != childList.end(); anIt++) {
        Child* aChild = *anIt;
        aChild->greedy_weight = (double)count;
        count++;
        double val = heuristic_upper / (aChild->greedy_weight + aSol->greedy_weight_sum);
        basesum = basesum + val;
        aChild->value = val;
        children.push_back(aChild);
    }
}

void PBS::get_options(Solution* sol, vector<int>& options) {

    vector<int> non_dominated(instance->alphabet_size,1);
    for (int j = 0; j < instance->alphabet_size; j++) {
        if ((sol->min_remaining)[j] > 0) {
            for (int k = 0; ((k < j) && (non_dominated[j] == 1)); k++) {
                if (((sol->min_remaining)[k] > 0) && (non_dominated[k] == 1)) {
                    int rel = sol->domination_relation(j,k);
                    if (rel == 1) non_dominated[k] = 0;
                    else {
                        if (rel == -1) non_dominated[j] = 0;
                    }
                }
            }
        }
        else non_dominated[j] = 0;
    }
    for (int j = 0; j < instance->alphabet_size; j++) {
        if (non_dominated[j] == 1) options.push_back(j);
    }
}

vector<Solution*> PBS::beam_construct(int beam_size, double mu, bool filter, int greedy_info) {

    Solution* bestSol = NULL;
    Solution* sol = new Solution(instance);

    list<Solution*> beam;
    beam.push_back(sol);

    vector<Solution*> bests;

    while (beam.size() > 0) {
        list<Child*> children;
        double basesum = 0.0;
        for (list<Solution*>::iterator sIt = beam.begin(); sIt != beam.end(); sIt++) {
            Solution* theSol = *sIt;
            vector<int> options;
            get_options(theSol,options);
            if (options.size() == 0) {
                if (bestSol == NULL) {
                    bestSol = theSol->copy();
                    Solution* hSol = theSol->copy();
                    bests.push_back(hSol);
                }
                else {
                    if (theSol->value() > bestSol->value()) {
                        delete(bestSol);
                        for (int li = 0; li < int(bests.size()); ++li) delete(bests[li]);
                        bests.clear();
                        bestSol = theSol->copy();
                        Solution* hSol = theSol->copy();
                        bests.push_back(hSol);
                    }
                    else if (theSol->value() == bestSol->value()) {
                        Solution* hSol = theSol->copy();
                        bests.push_back(hSol);
                    }
                }
            }
            else {
                if (greedy_info == 0) produce_rel_children(theSol,children,options,basesum);
                else produce_nb_children(theSol,children,options,basesum);
            }
        } 
        if (filter) filter_children(children,basesum);
        list<Solution*> new_beam;
        if (children.size() <= ((int)(mu * ((double)beam_size)))) {
            for (list<Child*>::iterator cIt = children.begin(); cIt != children.end(); cIt++) {
                Child* aChild = *cIt;
                Solution* newSol = (aChild->my_sol)->copy();
                newSol->add(aChild->letter);
                newSol->greedy_weight_sum = newSol->greedy_weight_sum + aChild->greedy_weight;
                int ub = newSol->upper_bound();
                new_beam.push_back(newSol);
                delete aChild;
            }
            children.clear();
        }
        else {
            for (int i = 0; i < ((int)(mu * ((double)beam_size))); i++) {
                list<Child*>::iterator chosenIt;
                double max_val = -1.0;
                for (list<Child*>::iterator cIt = children.begin(); cIt != children.end(); cIt++) {
                    Child * aChild = *cIt;
                    if (aChild->value > max_val) {
                        max_val = aChild->value;
                        chosenIt = cIt;
                    }
                }
                Solution* newSol = ((*chosenIt)->my_sol)->copy();
                newSol->add((*chosenIt)->letter);
                newSol->greedy_weight_sum = newSol->greedy_weight_sum + (*chosenIt)->greedy_weight;
                int ub = newSol->upper_bound();
                new_beam.push_back(newSol);
                basesum = basesum - (*chosenIt)->value;
                children.erase(chosenIt);
                delete(*chosenIt);
            }
            for (list<Child*>::iterator cIt = children.begin(); cIt != children.end(); cIt++) delete(*cIt);
            children.clear();
        }
        new_beam.sort(solution_compare);
        for (list<Solution*>::iterator sIt = beam.begin(); sIt != beam.end(); sIt++) delete(*sIt);
        beam.clear();
        bool delete_it = false;
        int last_ubv = -2;
        int bcount = 0;
        for (list<Solution*>::iterator sIt = new_beam.begin(); sIt != new_beam.end(); sIt++) {
            if (delete_it and last_ubv != (*sIt)->ub_value) delete(*sIt);
            else {
                beam.push_back(*sIt);
                bcount++;
                if (bcount >= beam_size) delete_it = true;
                last_ubv = (*sIt)->ub_value;
            }
        }
    }
    return bests;
}

void PBS::filter_children(list<Child*>& children, double& basesum) {

    for (list<Child*>::iterator it = children.begin(); it != children.end(); it++) {
        (*it)->non_dominated = 1;
        bool stop = false;
        for (list<Child*>::iterator itk = children.begin(); !stop; itk++) {
            if (*it == *itk) stop = true;
            else {
                if ((*it)->non_dominated == 1) {
                    int rel = child_domination_relation(*it,*itk);
                    if (rel == 1) (*itk)->non_dominated = 0;
                    else {
                        if (rel == -1) {
                            (*it)->non_dominated = 0;
                            stop = true;
                        }
                    }
                }
            }
        }
    }
    list<Child*> to_keep;
    for (list<Child*>::iterator it = children.begin(); it != children.end(); it++) {
        if ((*it)->non_dominated == 0) {
            basesum = basesum - (*it)->value;
            delete(*it);
        }
        else to_keep.push_back(*it);
    }
    children.clear();
    children = to_keep;
}

int PBS::child_domination_relation(Child* c1, Child* c2) {

    bool dominates = false;
    bool dominated = false;
    bool stop = false;
    for (int i = 0; ((i < instance->n_of_sequences) && !stop); i++) {
        if ((c1->my_sol)->next_char[i][c1->letter] < (c2->my_sol)->next_char[i][c2->letter]) dominates = true;
        else {
            if ((c1->my_sol)->next_char[i][c1->letter] > (c2->my_sol)->next_char[i][c2->letter]) dominated = true;
        }
        if (dominates && dominated) stop = true;
    }
    if (stop) return 0;
    else {
        if (dominates) return 1;
        else return -1;
    }
}


